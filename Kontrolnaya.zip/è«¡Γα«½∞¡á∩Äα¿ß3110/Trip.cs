﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace КонтрольнаяОрис3110
{
    public class Trip
    {
        public int Id { get; set; }
        public string Destination { get; set; }
        public string Transport { get; set; }
        public string Status { get; set; }
    }
}
