﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Web;
using КонтрольнаяОрис3110;

namespace КонтрольнаяОрис3110
{


        class Program
        {
            static TripStore store = new TripStore();

            static void Main(string[] args)
            {
                HttpListener server = new HttpListener();
                server.Prefixes.Add("http://localhost:8080/");
                server.Start();
                Console.WriteLine("Сервер запущен");

                while (true)
                {
                    HttpListenerContext ctx = server.GetContext();
                    string path = ctx.Request.Url.AbsolutePath;
                    string method = ctx.Request.HttpMethod;

                   
                    if (method == "GET" && path == "/trips")
                    {
                        store.trips.Sort((a, b) => string.Compare(a.Destination, b.Destination));


                        string html = "<meta charset='utf-8'>";
                        html += "<h2>Все поездки</h2>";
                        html += "<a href='/create'>Создать поездку</a><br><br>";
                        html += "<table border='1'>";
                        html += "<tr><td>ID</td><td>Куда</td><td>Транспорт</td><td>Статус</td></tr>";

                        for (int i = 0; i < store.trips.Count; i++)
                        {
                            html += "<tr><td>" + store.trips[i].Id + "</td><td>" + store.trips[i].Destination + "</td><td>" + store.trips[i].Transport + "</td><td>" + store.trips[i].Status + "</td></tr>";
                        }
                        html += "</table>";
                        Send(ctx, html);
                    }

                    else if (method == "GET" && path == "/details")
                    {
                        int id = int.Parse(ctx.Request.QueryString["id"]);
                        Trip t = null;
                        for (int i = 0; i < store.trips.Count; i++) { if (store.trips[i].Id == id) t = store.trips[i]; }

                        if (t == null)
                        {
                            ctx.Response.StatusCode = 404;
                            ctx.Response.Close();
                        }
                        else
                        {
                            string html = "<meta charset='utf-8'>"; 
                            html += "<h2>Поездка</h2>";
                            html += "Куда: " + t.Destination + "<br>";
                            html += "Транспорт: " + t.Transport + "<br>";
                            html += "Статус: " + t.Status + "<br>";
                            html += "<a href='/trips'>Назад</a>";
                            Send(ctx, html);
                        }
                    }

                    else if (method == "GET" && path == "/create")
                    {
                        string html = "<meta charset='utf-8'>";
                        html += "<h2>Новая поездка</h2>";
                        html += "<form method='POST' action='/save'>";
                        html += "Город: <input name='dest'><br>";
                        html += "Транспорт (train, plane, bus): <input name='trans'><br>";
                        html += "<button>ОК</button></form>";
                        Send(ctx, html);
                    }

                    else if (method == "POST" && path == "/save")
                    {
                        string body = new StreamReader(ctx.Request.InputStream).ReadToEnd();
                        string[] p = body.Split('&');
                        string d = "", t = "";

                        for (int i = 0; i < p.Length; i++)
                        {
                            string[] kv = p[i].Split('=');
                            if (kv.Length == 2)
                            {
                                if (kv[0] == "dest") d = kv[1].Replace("+", " ");
                                if (kv[0] == "trans") t = kv[1];
                            }
                        }

                        Trip newT = store.CreateTrip(d, t);
                        if (newT == null)
                        {
                            ctx.Response.StatusCode = 400;
                            ctx.Response.Close();
                        }
                        else
                        {
                            ctx.Response.StatusCode = 303;
                            ctx.Response.RedirectLocation = "/trips";
                            ctx.Response.Close();
                        }
                    }

                    else if (method == "PUT" && path == "/update")
                    {
                        int id = int.Parse(ctx.Request.QueryString["id"]);
                        string body = new StreamReader(ctx.Request.InputStream).ReadToEnd();
                        string[] p = body.Split('&');
                        string d = "", t = "", s = "";

                        for (int i = 0; i < p.Length; i++)
                        {
                            string[] kv = p[i].Split('=');
                            if (kv.Length == 2)
                            {
                                if (kv[0] == "dest") d = kv[1].Replace("+", " ");
                                if (kv[0] == "trans") t = kv[1];
                                if (kv[0] == "status") s = kv[1];
                            }
                        }

                        Trip found = null;
                        for (int i = 0; i < store.trips.Count; i++) { if (store.trips[i].Id == id) found = store.trips[i]; }

                        if (found == null)
                        {
                            ctx.Response.StatusCode = 404;
                            ctx.Response.Close();
                        }
                        else
                        {
                            found.Destination = d;
                            found.Transport = t;
                            found.Status = s;
                            ctx.Response.StatusCode = 204; 
                            ctx.Response.Close();
                        }
                    }
                    else
                    {
                        ctx.Response.StatusCode = 404;
                        ctx.Response.Close();
                    }
                }
            }

            static void Send(HttpListenerContext ctx, string text)
            {
                byte[] b = Encoding.UTF8.GetBytes(text);

                ctx.Response.ContentType = "text/html; charset=utf-8";

                ctx.Response.OutputStream.Write(b, 0, b.Length);
                ctx.Response.Close();
            }
        }
    
}



