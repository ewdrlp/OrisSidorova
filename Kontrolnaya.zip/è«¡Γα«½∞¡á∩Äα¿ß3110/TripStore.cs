﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace КонтрольнаяОрис3110
{
  
        public class TripStore
        {
            public List<Trip> trips = new List<Trip>();
            public int nextId = 1;

            public Trip CreateTrip(string dest, string trans)
            {
               
                if (dest == null || dest.Length < 3 || dest.Length > 80) return null;
                if (trans != "train" && trans != "plane" && trans != "bus") return null;

                Trip t = new Trip();
                t.Id = nextId++;
                t.Destination = dest;
                t.Transport = trans;
                t.Status = "planned";
                trips.Add(t);
                return t;
            }
        }
}


