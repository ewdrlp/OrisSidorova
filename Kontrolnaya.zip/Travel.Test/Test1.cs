﻿
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using КонтрольнаяОрис3110; 

namespace Travel.Test
{
    [TestClass]
    public class Test1
    {
        [TestMethod]
        public void Create_Valid_SetsPlannedStatusAndAssignsId()
        {
            var store = new TripStore();
            var t = store.CreateTrip("Moscow", "train");

            Assert.AreEqual(1, t.Id);
            Assert.AreEqual("Moscow", t.Destination);
            Assert.AreEqual("train", t.Transport);
            Assert.AreEqual("planned", t.Status);
        }

        [TestMethod]
        public void Create_InvalidTransport_Throws()
        {
            var store = new TripStore();
            
            Assert.ThrowsException<Exception>(() => store.CreateTrip("Moscow", "car"));
        }
    }
}
