﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace oris0310
{
    internal class Settings
    {
        public string[] Prefixes { get; set; }
    }
}
